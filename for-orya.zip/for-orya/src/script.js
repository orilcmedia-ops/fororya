const noBtn = document.getElementById("noBtn");
const card = document.querySelector(".card");

function randomMove() {
  const maxX = card.clientWidth - noBtn.offsetWidth;
  const maxY = card.clientHeight - noBtn.offsetHeight;
  const x = Math.random() * maxX;
  const y = Math.random() * maxY;
  noBtn.style.left = x + "px";
  noBtn.style.top = y + "px";
}

setInterval(randomMove, 700);

function yesClick() {
  document.body.innerHTML = `
    <div style="
      display:flex;
      flex-direction:column;
      justify-content:center;
      align-items:center;
      height:100vh;
      background:#ffffff; 
      color:#ff4d6d;
      text-align:center;
      padding:20px;
      font-family: Arial, sans-serif;
    ">
      <h1>waiting for you!!💖</h1>
      <img
        src="https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExcGIyenN0bG52MmxzcHpiOGx4dnA0ODdobnpwcjU4MmYwNXd0NzJlNCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/iUYkb29OtCeOgsnhnI/giphy.gif"
        style="width:250px; margin-top:20px; border-radius:20px;"
      >
    </div>
  `;
}